<!-- visual-only; ZIP-only; 不支持 JSON 往返 -->
![原尺寸完整图片](resources/original.png)
