(() => {
  // extension/src/core/recipes.js
  function fourierPath(state) {
    const { harmonics, amplitude, phase } = state;
    if (!Number.isInteger(harmonics) || harmonics < 1 || harmonics > 12 || !Number.isFinite(amplitude) || amplitude < 0 || amplitude > 1.5 || !Number.isFinite(phase) || phase < -3.14 || phase > 3.14) throw Error("Fourier \u53C2\u6570\u8D85\u9650");
    const points = [];
    for (let i = 0; i <= 240; i++) {
      const x = i / 240 * 2 * Math.PI;
      let y = 0;
      for (let n = 1; n <= harmonics; n++) y += Math.sin(n * x + phase) / n;
      points.push((i ? "L" : "M") + (i * 2.5).toFixed(2) + "," + (90 - y * amplitude * 32).toFixed(2));
    }
    return points.join(" ");
  }
  function tableOrder(rows, state) {
    if (!Number.isFinite(state.minimum) || state.minimum < 0 || state.minimum > 50 || !["asc", "desc"].includes(state.direction) || rows.length > 200 || rows.some((r) => r.length !== 2 || r.some((c) => typeof c !== "string" || c.length > 100) || !Number.isFinite(Number(r[1])) || Number(r[1]) < 0 || Number(r[1]) > 50)) throw Error("\u8868\u683C\u53C2\u6570\u8D85\u9650");
    return rows.map((_, i) => i).filter((i) => Number(rows[i][1]) >= state.minimum).sort((a, b) => (Number(rows[a][1]) - Number(rows[b][1])) * (state.direction === "asc" ? 1 : -1) || a - b);
  }

  // extension/src/core/runtime.js
  var specs = JSON.parse(document.querySelector('meta[name="uip-interactions"]').content);
  var get = (path) => document.querySelector(`[data-uip-node="${path}"]`);
  for (const spec of specs) {
    const b = Object.fromEntries(Object.entries(spec.bindings).map(([k, p]) => [k, get(p)])), state = { ...spec.state };
    if (spec.recipe === "fourier@1") {
      const update = () => {
        try {
          const next = { harmonics: Number(b.harmonics.value), amplitude: Number(b.amplitude.value), phase: Number(b.phase.value) };
          const path = fourierPath(next);
          b.curve.setAttribute("d", path);
          b.output.textContent = `N=${next.harmonics} \xB7 A=${next.amplitude} \xB7 \u03C6=${next.phase}`;
          Object.assign(state, next);
        } catch {
          for (const key of ["harmonics", "amplitude", "phase"]) b[key].value = state[key];
        }
      };
      for (const key of ["harmonics", "amplitude", "phase"]) {
        b[key].disabled = false;
        b[key].addEventListener("input", update);
      }
    } else if (spec.recipe === "table@1") {
      const rows = [...b.body.children], data = rows.map((row) => [...row.children].map((c) => c.textContent));
      const update = () => {
        try {
          const indices = tableOrder(data, state), visible = new Set(indices);
          for (let i = 0; i < rows.length; i++) rows[i].hidden = !visible.has(i);
          b.body.replaceChildren(...indices.map((i) => rows[i]), ...rows.filter((_, i) => !visible.has(i)));
          b.output.textContent = `\u2265${state.minimum} \xB7 ${state.direction}`;
        } catch {
          b.filter.value = spec.state.minimum;
        }
      };
      b.filter.disabled = false;
      b.sort.disabled = false;
      b.filter.addEventListener("input", () => {
        state.minimum = Number(b.filter.value);
        update();
      });
      b.sort.addEventListener("click", () => {
        state.direction = state.direction === "asc" ? "desc" : "asc";
        update();
      });
      update();
    }
  }
})();
