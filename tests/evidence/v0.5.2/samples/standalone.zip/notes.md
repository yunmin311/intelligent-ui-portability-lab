<!-- capability: visual-only; 不含原始交互 -->
![本地图片](resources/r0.png)
